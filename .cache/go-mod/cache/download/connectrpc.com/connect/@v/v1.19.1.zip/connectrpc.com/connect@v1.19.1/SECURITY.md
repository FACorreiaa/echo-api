Security Policy
===============

This project follows the [Connect security policy and reporting
process](https://connectrpc.com/docs/governance/security).
