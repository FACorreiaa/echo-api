INSERT INTO article (id, content) VALUES ('id_0002',  E'# My second 

markdown doc

first paragraph

-- with a comment
    -- with an indent comment

second paragraph');